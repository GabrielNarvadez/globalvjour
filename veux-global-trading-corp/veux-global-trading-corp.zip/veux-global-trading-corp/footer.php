<footer class="footer footer2" id="footer">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-9 wow zoomIn" data-wow-duration="700ms" data-wow-delay="300ms">
                            <div class="copyRight">
                                &copy; Vuex Global Trading Corp.<script>document.write(new Date().getFullYear())</script> | All Rights Reserved. 
                            </div>
                        </div>
                        <div class="col-lg-3 wow zoomIn" data-wow-duration="700ms" data-wow-delay="300ms">
                            <div class="footerSocial">
                                
                            </div>
                        </div>
                    </div>
                </div>
            </footer>
            <div class="subscriptionSuccess">
                <div class="subsNotice">
                    <i class="fa fa-thumbs-o-up closers"></i>
                    <div class="clearfix"></div>
                    <p class="closers">Subscription Request Successfully placed!</p>
                </div>
            </div>
            <div class="contactSuccess">
                <div class="consNotice">
                    <i class="fa fa-thumbs-o-up closers"></i>
                    <div class="clearfix"></div>
                    <p class="closers">Your Message successfully sent!</p>
                </div>
            </div>
        </div>
        <a id="backToTop" href="#"><i class="fa fa-angle-double-up"></i></a>
        <!-- Include All JS -->
        <script type="text/javascript" src="js/jquery.js"></script>
        <script type="text/javascript" src="js/bootstrap.min.js"></script>
        <script type="text/javascript" src="js/mixer.js"></script>
        <script type="text/javascript" src="js/wow.min.js"></script>
        <script type="text/javascript" src="js/jquery.appear.js"></script>
        <script type="text/javascript" src="js/prettyPhoto.js"></script>
        <script type="text/javascript" src="js/jquery.shuffle.min.js"></script>
        <script type="text/javascript" src="js/owl.carousel.js"></script>
        <script type="text/javascript" src="js/mixer.js"></script>
        <script type="text/javascript" src="js/jquery.magnific-popup.min.js"></script>
        <script type="text/javascript" src="js/modernizr.custom.js"></script>
        <script type="text/javascript" src="js/classie.js"></script>
        <script type="text/javascript" src="js/blogpopup.js"></script>
        <script type="text/javascript" src="js/jquery.themepunch.tools.min.js"></script>
        <script type="text/javascript" src="js/jquery.themepunch.revolution.min.js"></script>
        <script type="text/javascript" src="js/theme.js"></script>
    </body>
</html>